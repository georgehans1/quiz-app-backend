INSERT INTO quizapp.user_authorities (authority_id,user_id) VALUES
	 ('ba824ffa-b91a-4f91-8510-34d5b9ad62f0','ce8554c5-f9c4-4d6d-bead-d19b408d5856'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','859fade6-3561-40f1-a0a4-55a078549f46'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','c7938c79-0a20-4646-a8d6-cf4ccc266be3'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','357aec08-5afc-4bdb-a14a-04ab55f9e4fb'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','1a23529a-9059-4371-97f0-8cfd06f3f311'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','d1db0508-391e-48f5-89e9-b758ab7f868c'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','742be956-a49f-42f7-80f6-5b65aedfa6c8'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','f01a1c93-3bb3-4f89-9cdc-d98d58389934'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','8877b6a7-40ea-46d8-830a-7656258b7b4a'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','66de5e9f-7e8b-4c72-911b-60327e22ec7e');
INSERT INTO quizapp.user_authorities (authority_id,user_id) VALUES
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','afe02a21-9477-433a-8a6f-36b525ac9fd5'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','50c439fe-b410-4298-95d2-0db595fe12d1'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','3c167e2d-e44f-46d6-93f1-96231788ff37'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','0ce408dc-7559-499c-8b79-d10296f9d6db'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','4e0f9108-db63-4d93-ba2e-376270416db9'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','4af956dc-39fa-49fa-b19b-a69aed6f0dff'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','aae6d15e-5559-4e31-be25-0cfd410b6800'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','1f02cfc2-97c6-4e21-933c-a4fd99dc5bd0'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','5baeb71f-d7a0-4152-b215-591a1a22ba1e'),
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','1e138512-1a96-4bad-bab8-8e63a168a4a6');
