INSERT INTO quizapp.authority (id,"name") VALUES
	 ('505630e7-e0fe-4dbd-b7e5-9941dc70151f','USER'),
	 ('ba824ffa-b91a-4f91-8510-34d5b9ad62f0','ADMIN');
